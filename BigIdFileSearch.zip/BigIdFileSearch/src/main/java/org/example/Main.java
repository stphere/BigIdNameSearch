package org.example;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public class Main {
    public static void main(String[] args) throws IOException, ExecutionException, InterruptedException {
        long startTime = System.currentTimeMillis();
        System.out.println("Started reading the large text file...");
        Map<String, List<OffsetLocations>> combinedResults = new HashMap<>();

        FileReader file = new FileReader("D:\\Workspces\\Demo\\BigIdFileSearch\\big.txt");
        BufferedReader bufferedReader = new BufferedReader(file);

        String textToSearch = "achievement";

        splitAndSearchInParts(combinedResults, bufferedReader, textToSearch);

        // Call the aggregator to combine and print the results
        Aggregator.aggregateAndPrint(combinedResults);
    }

    private static void splitAndSearchInParts(Map<String, List<OffsetLocations>> combinedResults, BufferedReader bufferedReader, String textToSearch) throws IOException, InterruptedException, ExecutionException {
        StringBuilder stringBuilder = new StringBuilder();
        String line;
        int lineCount = 1;


        // Read 1000 lines from the file and send each part to the matcher
        while ((line = bufferedReader.readLine()) != null) {
            lineCount++;
            stringBuilder.append(line).append("\n");

            // this will slice each lines in 1000s
            if (lineCount % 1000 == 0) {
                String part = stringBuilder.toString();
                stringBuilder.setLength(0); // Clear the StringBuilder

                // Send the part to the matcher asynchronously
                CompletableFuture<Map<String, List<OffsetLocations>>> matcherResult
                        = Matcher.matchAsync(textToSearch, part, lineCount - 1000);

                // Aggregate the results from the matcher
                Map<String, List<OffsetLocations>> matcherMap = matcherResult.get(); // Waits for completion
                for (Map.Entry<String, List<OffsetLocations>> entry : matcherMap.entrySet()) {
                    combinedResults.merge(entry.getKey(), entry.getValue(), (oldValue, newValue) -> {
                        oldValue.addAll(newValue);
                        return oldValue;
                    });
                }
            }
        }
    }
}
