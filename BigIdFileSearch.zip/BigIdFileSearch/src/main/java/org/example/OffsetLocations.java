package org.example;

public class OffsetLocations {
    int lineOffset;
    int charOffset;

    public OffsetLocations(int lineOffset, int charOffset) {
        this.lineOffset = lineOffset;
        this.charOffset = charOffset;
    }

    public int getLineOffset() {
        return lineOffset;
    }

    public void setLineOffset(int lineOffset) {
        this.lineOffset = lineOffset;
    }

    public int getCharOffset() {
        return charOffset;
    }

    public void setCharOffset(int charOffset) {
        this.charOffset = charOffset;
    }

    @Override
    public String toString() {
        return "OffsetLocations{" +
                "lineOffset=" + lineOffset +
                ", charOffset=" + charOffset +
                '}';
    }
}
