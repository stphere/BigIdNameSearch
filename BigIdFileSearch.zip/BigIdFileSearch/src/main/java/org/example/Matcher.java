package org.example;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Matcher {
    static final ExecutorService executorService = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());

    // Method to match asynchronously
    public static CompletableFuture<Map<String, List<OffsetLocations>>> matchAsync(String textToSearch,
                                                                                   String part, int lineNo) {
        return CompletableFuture.supplyAsync(() -> match(textToSearch, part, lineNo), executorService);
    }

    // Method to match and find locations of given set of strings
    private static Map<String, List<OffsetLocations>> match(String textToSearch, String part, int lineNo) {
        Map<String, List<OffsetLocations>> resultMap = new HashMap<>();
        List<String> lines = List.of(part.split("\n"));

        for (String line : lines) {
            int i = line.indexOf(textToSearch);
            if (i != -1) {
                while (i >= 0) {
                    List<OffsetLocations> locations
                            = resultMap.compute(textToSearch, (k, v) -> v == null ? new ArrayList<>() : v);
                    locations.add(new OffsetLocations(lineNo, i));
                    i = line.indexOf(textToSearch, i + 1);
                }

            }
            lineNo++;
        }


        return resultMap;
    }
}
