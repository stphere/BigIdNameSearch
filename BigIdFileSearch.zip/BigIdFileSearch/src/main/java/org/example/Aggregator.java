package org.example;

import java.util.List;
import java.util.Map;

public class Aggregator {
    public static void aggregateAndPrint(Map<String, List<OffsetLocations>> combinedResults) {
        System.out.println("Search completed..Printing the results...");
        combinedResults.entrySet().stream().forEach(entry -> {
            System.out.println(entry.getKey() + " : " + entry.getValue().toString());

        });

    }
}
